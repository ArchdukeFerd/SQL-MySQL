package com.alura.jdbc.controller;

import java.util.ArrayList;
import java.util.List;

public class CategoriaController {

	public List<?> listar() {
		// TODO
		return new ArrayList<>();
	}

    public List<?> cargaReporte() {
        // TODO
        return new ArrayList<>();
    }

}
